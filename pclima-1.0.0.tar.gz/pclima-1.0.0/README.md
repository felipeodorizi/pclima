
# PClima API

**PClima API** é um simples conversor de temperatura
Celsius-Fahrenheit (e vice-versa) escrito em Python.

## Funções

