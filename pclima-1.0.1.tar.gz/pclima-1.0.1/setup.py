
from setuptools import setup

setup(
    name = 'pclima',
    version = '1.0.1',
    author = 'Felipe Odorizi de Mello',
    author_email = 'felipeodorizi@gmail.com',
    packages = ['pclima'],
    description = 'Módulo para recuperação de dados climáticos do PCBr.',
    long_description = 'Módulo para recuperação de dados climáticos do PCBr. '
                        + 'A documentação do Projeto pode ser encontrada no Portal, '
                        + 'http://pclima.inpe.br/',
    url = 'https://github.com/felipeodorizi/pclima',
    project_urls = {
        'Código fonte': 'https://github.com/felipeodorizi/pclima',
        'Download': 'https://github.com/felipeodorizi/pclima/pclima-1.0.1.tar.gz'
    },
    license = 'MIT',
    keywords = 'conversor temperatura alura',
    classifiers = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Portuguese (Brazilian)',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Internationalization',
        'Topic :: Scientific/Engineering :: Physics'
    ]
)